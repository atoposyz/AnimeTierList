<template>
	<div class="home" @mouseup="change_event_handler">
		<div class="opt">
			<div class="in-output">
				<button @click="writer" v-show="!ifimport && !ifsave">{{ writertitle }}</button>
				<button @click="clearcontent" v-show="!ifimport && !ifsave">{{ cleartitle }}</button>
				<button @click="changesave" v-show="!ifimport">{{ savetitle }}</button>
				<button @click="changeimport" v-show="!ifsave">{{ importtitle }}</button>
			</div>
			<div class="save-as" v-show="ifsave">
				<button @click="save_data_into_cookie">{{ cache_title }}</button>
				<button @click="savejson">json</button>
				<button @click="captureimg">image</button>
			</div>
			<div class="importopt" v-show="ifimport">
				<button>代码</button>
				<button class="file"><input type="file" @change="handleFileUpload" accept=".json" />json</button>
			</div>
			<div class="zhanweifu" v-show="!ifsave & !ifimport">
				<button style="border: 0; background-color: rgba(0, 0, 0, 0)"></button>
			</div>
		</div>

		<RowSettingBox v-if="ifsetting" :index="this.settingindex" @closesettingbox="handleclosesettingbox" />
		<SearchAnimeBox v-if="ifsearch" @closesearchbox="handleclosesearchbox" />

		<div ref="imageRankTable" class="imageranktable">
			<div class="tabletitle center">
				年度动画分组
			</div>
			<div class="writer" v-show="iwriter">
				<span>填表人：</span>
				<input type="text" placeholder="写上你的名字" size="10rem" oninput="this.style.width = (this.value.length>18?this.value.length:10) + 'rem';">
			</div>
			<template v-for="rankitem in store.ranklist" :key="rankitem.index">
				<ImageRankTable :index="rankitem.index" v-if="rankitem.index > 0"
					@opensettingbox="handleopensettingbox" />
			</template>
			<!-- <div class="tablefooter">
				atoposyz.github.io/anime-rank/index.html 动画信息来自Bangumi
			</div> -->
		</div>

		<div>
			<SortableImageList ref="sortableImageList" @opensearchbox="handleopensearchbox" />
		</div>
		<div ref="combinedContainer" class="combined-container" style="display: none"></div>
	</div>
	<AppFooter />
</template>

<script>
import SortableImageList from '@/components/SortableImageList.vue';
import ImageRankTable from '@/components/ImageRankTable.vue';
import RowSettingBox from './components/RowSettingBox.vue';
import SearchAnimeBox from '@/components/SearchAnimeBox.vue';
import AppFooter from './components/Footer.vue';
import Cookies from 'js-cookie';
import { store } from '@/utils/store.js'
import html2canvas from 'html2canvas';
import * as htmlToImage from 'html-to-image';
import { toPng, toJpeg, toBlob, toPixelData, toSvg } from 'html-to-image';

export default {
	components: {
		ImageRankTable,
		SortableImageList,
		SearchAnimeBox,
		AppFooter,
		RowSettingBox,
	},
	data() {
		return {
			store,
			iwriter: false,
			ifsetting: false,
			ifsearch: false,
			ifsave: false,
			ifimport: false,
			writertitle: "填表人OFF",
			savetitle: '保存',
			cache_title: '网页缓存',
			importtitle: "导入",
			cleartitle: '清空',
			settingindex: 1,
		}
	},
	mounted() {
		// this.empty_ranklist = JSON.parse(JSON.stringify(this.ranklist)); // 记录初始值
		this.load_data_from_cookie();                                    // 初始化时：试图从 cookie 加载上次的历史信息
	},
	beforeUnmount() {
	},
	methods: {
		change_event_handler() {

		},
		add_new_image_into_sorted(new_anime_image_url) {
			this.sortable_images_urls.push({
				src: new_anime_image_url
			});
		},
		clear_ranklist() { // 清空整个 ranklist
			store.ClearRankList();
		},
		set_cookie(name, value) {
			Cookies.set(name, value, { expires: 30 }); // 30 天后过期
		},
		get_cookie(name) {
			return Cookies.get(name); // 获取指定名称的 cookie
		},
		handleopensettingbox(index) {
			this.settingindex = index;
			console.log("receive trying opensettingbox No." + this.settingindex);
			this.ifsetting = true;
		},
		handleclosesettingbox() {
			this.ifsetting = false;
		},
		handleopensearchbox() {
			this.ifsearch = true;
		},
		handleclosesearchbox() {
			this.ifsearch = false;
		},
		writer() {
			this.iwriter = !this.iwriter;
			if(this.iwriter) {
				this.writertitle = "填表人ON";
			} else {
				this.writertitle = "填表人OFF";
			}
		},
		clearcontent() {
			store.ClearRankList();
		},
		changesave() {
			this.ifsave = !this.ifsave;
			if (this.ifsave) {
				this.savetitle = '取消';
			} else {
				this.savetitle = '保存';
			}
		},
		changeimport() {
			this.ifimport = !this.ifimport;
			if (this.ifimport) {
				this.importtitle = "取消";
			} else {
				this.importtitle = "导入";
			}
		},
		save_data_into_cookie(flag = true) {
			this.set_cookie("rank", JSON.stringify(store.ranklist, null, 2));
			this.set_cookie("sortable", JSON.stringify(store.sortablelist, null, 2));
			console.log("saving data into cookie.");
			if (flag) {
				alert("已保存！");
			}
		},
		load_main_data_from_cookie() {
			const json_string = this.get_cookie("rank");
			if (json_string == null || json_string == "") {  // 当前没有可用 json
				this.save_data_into_cookie(false);           // 存一个进去
				return;
			}
			const json_object = JSON.parse(json_string);
			this.loadjson(json_object);
			console.log("load main data from cookie.");
		},
		load_sort_data_from_cookie() {
			const json_string = this.get_cookie("sortable");
			if (json_string == null || json_string == "") {  // 当前没有可用 json
				this.save_data_into_cookie(false);           // 存一个进去
				return;
			}
			const json_object = JSON.parse(json_string);
			this.loadsortjson(json_object);
			console.log("load sort data from cookie.");
		},
		load_data_from_cookie() {
			this.load_main_data_from_cookie();
			this.load_sort_data_from_cookie();
		},
		captureimg() {
			const element = this.$refs.imageRankTable;
			// 克隆整个元素，保留原始网页不受影响
			var settingsDivs = element.querySelectorAll('div.settings'); // 查找所有 class 为 settings 的 div
			settingsDivs.forEach(div => div.style.display = "none"); // 删除每一个找到的 div
			// settingsDivs = element.querySelectorAll("image-rank-row");
			// settingsDivs.forEach(div => div.style.boxShadow = "");
			// settingsDivs = element.querySelectorAll("rank-name");
			// settingsDivs.forEach(div => div.style.boxShadow = "");
			html2canvas(element, { useCORS: true }).then(canvas => {
				const link = document.createElement('a');
				link.href = canvas.toDataURL('image/png');
				link.download = 'ImageRankTable.png';
				link.click();
			});
			settingsDivs = element.querySelectorAll('div.settings');
			settingsDivs.forEach(div => div.style.display = "flex");
			// settingsDivs = element.querySelectorAll("image-rank-row");
			// settingsDivs.forEach(div => div.style.boxShadow = "0 2px 6px rgba(0, 0, 0, 0.05)");
			// settingsDivs = element.querySelectorAll("rank-name");
			// settingsDivs.forEach(div => div.style.boxShadow = "0 2px 6px rgba(0, 0, 0, 0.1)");
			this.changesave();
		},
		savejson() {
			const json = store.DumpJson();
			const blob = new Blob([json], { type: 'application/json' });
			const url = URL.createObjectURL(blob);
			const a = document.createElement('a');
			a.href = url;
			a.download = 'items.json';
			a.click();
			URL.revokeObjectURL(url);
			this.changesave();
		},
		loadjson(json_object) {
			store.LoadRankList(json_object);
		},
		
		loadsortjson(json_object) {
			store.LoadSortableList(json_object);
		},
		importnew() {

		},
		handleFileUpload(event) {
			const file = event.target.files[0]; // Get the first selected file
			if (file) {
				if (file.type === 'application/json') {
					const reader = new FileReader();

					reader.onload = (e) => {
						try {
							const json_file = JSON.parse(e.target.result);
							this.loadjson(json_file.rank); // Parse JSON data
							this.loadsortjson(json_file.sortable);
							this.changeimport();
						} catch (error) {
							console.error('Error parsing JSON:', error);
						}
					};

					reader.onerror = (error) => {
						console.error('Error reading file:', error);
					};

					reader.readAsText(file); // Read file content as text
				} else {
					alert('Please upload a valid JSON file.');
				}
			}
		},
	}
};
</script>
<style scoped>
.home {
	display: block;
	gap: 20px;
	max-width: 1000px;
	margin-left: auto;
	margin-right: auto;
	margin-top: 50px;
	padding: 20px;
	background-color: #ffffff;
	border-radius: 10px;
	box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
	border: 1px solid #e0e0e0;
}

.opt {
	margin-bottom: 20px;
	text-align: right;
	margin-right: 5px;
}

.writer{
	margin-right: 5px;
	margin-bottom: 15px;
	margin-left: auto;
	display: flex;
	justify-content: flex-end;
	font: 15px sans-serif;
}

.writer input {
	width: auto;
    min-width: 5px; /* 设置最小宽度 */
	border: none; 
	background: none; 
	padding: 0;
	outline: none;
	font: 15px sans-serif;
}

.imageranktable {
	margin-top: 50px;
	padding: 30px;
}

.tabletitle {
	font: 30px sans-serif;
	margin-bottom: 15px;
	
}
.tablefooter{
	font: 12px sans-serif;
	color: #777777;
}
.center {
	display: flex;
	justify-content: center;
}

button {
	position: relative;
	display: inline-block;
	background: #d0eeff;
	border: 1px solid #99d3f5;
	border-radius: 4px;
	padding: 4px 12px;
	overflow: hidden;
	color: #1e88c7;
	text-decoration: none;
	text-indent: 0;
	line-height: 20px;
	font: 20px sans-serif;
}

.file input {
	position: absolute;
	font-size: 100px;
	right: 0;
	top: 0;
	opacity: 0;
}

.file:hover {
	background: #aadffd;
	border-color: #78c3f3;
	color: #004974;
	text-decoration: none;
}
</style>
